<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Freelance\lineclear_revamp\lineclear-cms\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>